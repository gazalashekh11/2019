import {Recipe} from './recipe.modal';
import {Injectable} from '@angular/core';
import {Ingredient} from '../shared/ingredient.modal';
import {ShoppingListService} from '../shopping-list/shopping-list.service';

@Injectable()
export class RecipeService{
  private recipes:Recipe[]=[
    new Recipe('test recipe 1',
      'test',
      'https://www.tasteofhome.com/wp-content/uploads/2017/10/Healthier-than-Egg-Rolls_EXPS_SDON17_55166_C06_23_6b-696x696.jpg',
        [new Ingredient('Fish',1),
              new Ingredient('Potato',1),
        ]),
    new Recipe('test recipe 2',
      'test',
      'https://www.tasteofhome.com/wp-content/uploads/2017/10/Healthier-than-Egg-Rolls_EXPS_SDON17_55166_C06_23_6b-696x696.jpg',
        [new Ingredient('Egg',1),
        new Ingredient('Banana',1),
        ]),
    new Recipe('test recipe 3',
      'test',
      'https://www.tasteofhome.com/wp-content/uploads/2017/10/Healthier-than-Egg-Rolls_EXPS_SDON17_55166_C06_23_6b-696x696.jpg',
      [new Ingredient('Meat',1),
        new Ingredient('milk',1),
      ]),
  ];

  constructor(private shoppingListService:ShoppingListService){

  }
  getRecipes(){
    return this.recipes.slice();  /// need to understand
  }
  getRecipe(index:number){
    return this.recipes[index]
  }
  addIngredientToShoppingList(ingredients:Ingredient[]){
      this.shoppingListService.addIngredients(ingredients);
  }

}
