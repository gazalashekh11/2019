import {Ingredient} from '../shared/ingredient.modal';
import {Subject} from 'rxjs';



export class ShoppingListService{
  ingredientChanged = new Subject<Ingredient[]>();
  ingredients : Ingredient [] = [
    new Ingredient('Apple',5),
    new Ingredient('Tomato',7),
    new Ingredient('Vineger',5),
  ];
  getIngredient(){
    return this.ingredients.slice();
  }

  addIngredient(ingredient:Ingredient){
    this.ingredients.push(ingredient);
    // @ts-ignore
    this.ingredientChanged.next(this.ingredients.slice());
  }

  addIngredients(ing:Ingredient[]){
    // for(let i of ing){
    //   this.addIngredient(i);
    // }

    this.ingredients.push(...ing);
    // @ts-ignore
    this.ingredientChanged.next(this.ingredients.slice());
  }


}
